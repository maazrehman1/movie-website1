


const Sdata = [

    {
        id: 1,
        imgsrc:"/img/bbd.jpeg",
        sname:"Breaking Bad", 
        stitle:"A Orignal Netflix Series",
        blink:"https://www.netflix.com/pk/title/70143836",
    },



    {
        id: 2,
        imgsrc:"/img/mh.jpeg",
        sname:"Money Heist",
        stitle:"A Orignal Netflix Series",
        blink:"https://www.netflix.com/pk/title/80192098",

    },

    {
        id: 3,
        imgsrc:"/img/pb.jpg",
        sname:"Peaky Blinders",
        stitle:"A Orignal Netflix Series",
        blink:"https://www.netflix.com/pk/title/80002479",

    },

    {
        id: 4,
        imgsrc:"/img/sedu.jpeg",
        sname:"Sex Education",
        stitle:"A Orignal Netflix Series",
        blink:"https://www.netflix.com/pk/title/80197526",

    },

    {
        id: 5,
        imgsrc:"/img/st.png",
        sname:"Stranger Things",
        stitle:"A Orignal Netflix Series",
        blink:"https://www.netflix.com/pk/title/80057281",

    },

    {
        id: 6,
        imgsrc:"/img/wtchr.jpg",
        sname:"The Witcher",
        stitle:"A Orignal Netflix Series",
        blink:"https://www.netflix.com/pk/title/80189685",

    },
];

export default Sdata;
