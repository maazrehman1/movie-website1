const Bdata = [
{
    id: 1,
    link:"https://www.netflix.com/pk/",
    bname:"Home",
},

{
    id: 2,
    link:"https://www.netflix.com/pk/",
    bname:"Main",
},
{
    id: 3,
    link:"https://www.netflix.com/pk/",
    bname:"Categories",
},
{
    id: 4,
    link:"https://www.netflix.com/pk/",
    bname:"Contact Us",
}
];

export default Bdata;